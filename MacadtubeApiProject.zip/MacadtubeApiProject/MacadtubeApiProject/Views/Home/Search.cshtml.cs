using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MacadtubeApiProject.Views.Home
{
    public class SearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
