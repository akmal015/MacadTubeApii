﻿public class MacadTubeVideo
{
}